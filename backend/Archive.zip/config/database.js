import { Sequelize } from "sequelize";

const db = new Sequelize('stukm23', 'mlbakipg_admin', 'admSTUKM23', {
    host: 'api.stukmumn.com',
    dialect: 'mysql',
});

export default db;
