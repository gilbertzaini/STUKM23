import User from "../models/User.js";

export const loggedInUser = async (req, res) =>{
    if(!req.session.userId){
        return res.status(401).json({msg: "Mohon login ke akun Anda!"});
    }
    const user = await User.findOne({
        attributes:['userId','nama','nim', 'jurusan', 'angkatan', 'ukm'],
        where: {
            userId: req.session.userId
        }
    });
    if(!user) return res.status(404).json({msg: "User tidak ditemukan"});
    res.status(200).json(user);
}